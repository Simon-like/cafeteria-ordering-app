
## FilePicker 文件选择上传

> **组件名：uni-file-picker**
>  代码块： `uFilePicker`


文件选择上传组件，可以选择图片、视频等任意文件并上传到当前绑定的服务空间

### [查看文档](https://uniapp.dcloud.io/component/uniui/uni-file-picker)
#### 如使用过程中有任何问题，或者您对uni-ui有一些好的建议，欢迎加入 uni-ui 交流群：871950839 