export interface AllowedComponentProps {
  class?: unknown;
  style?: unknown;
}

export interface VNodeProps {
  key?: string | number | symbol;
  ref?: unknown;
}
